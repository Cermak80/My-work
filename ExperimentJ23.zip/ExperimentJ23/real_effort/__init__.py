from otree.api import *
import random
import base64
c = Currency
from PIL import Image, ImageDraw, ImageFilter, ImageFont
import random
doc = """
Your app description
"""


class Constants(BaseConstants):
    name_in_url = 'typing_task'
    players_per_group = None
    num_rounds = 1
    available_chars = list('abcdefghjkmnpqrstuvwx123456789')


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    pocet_opakovani = models.IntegerField()
    progresbar = models.IntegerField(initial=1)
    retezec = models.StringField()
    def generate_string(Player):
        length = 10  # Délka řetězce je náhodně mezi 5 a 10 znaky
        string = ''.join(random.choices(Constants.available_chars, k=length))  # Vygenerujeme náhodný řetězec
        Player.participant.vars['string'] = string
        Player.retezec = string
        # Vytvoření prázdného obrázku s bílým pozadím
        img = Image.new('RGB', (500, 100), color='white')
        # Vytvoření instance ImageDraw pro kreslení na obrázek
        draw = ImageDraw.Draw(img)
        text = string
        font = ImageFont.truetype('arial.ttf', 40)
        # Náhodné rozmazání textu
        for i in range(len(text)):
            # Náhodná velikost rozmazání pro každý znak
            radius = random.randint(1, 4)

            # Náhodná pozice rozmazání pro každý znak
            x = random.randint(-2, 4)
            y = random.randint(-2, 4)

            # Kreslení rozmazaného znaku
            draw.text((i * 50 + x, y), text[i], font=font, fill='black')
            draw.text((i * 50 + x + radius, y), text[i], font=font, fill='black')
            draw.text((i * 50 + x - radius, y), text[i], font=font, fill='black')
            draw.text((i * 50 + x, y + radius), text[i], font=font, fill='black')
            draw.text((i * 50 + x, y - radius), text[i], font=font, fill='black')
        # Uložení rozmazaného obrázku
        img.save(f'real_effort/static/imgs/bt{Player.id_in_group}.png')

    def generate_pocet_opakovani(Player):
        Player.pocet_opakovani = 10


class Introduction(Page):
    @staticmethod
    def before_next_page(player, timeout_happened):
        player.generate_string()
        player.generate_pocet_opakovani()


class Task(Page):

    def vars_for_template(player:Player):
        if 'string' not in player.participant.vars:  # Pokud řetězec ještě nebyl vygenerován, vygenerujeme jej
            player.group.generate_string()
        return {
            'original': player.retezec,# Řetězec k odhadnutí
            'progresbar': player.progresbar,
            'pocet_opakovani': player.pocet_opakovani,
            'id': player.id_in_group
        }

    @staticmethod
    def live_method(player, data):
        player.generate_string()
        response = dict()
        if player.pocet_opakovani == player.progresbar:
            response.update(t='Hotovson')
        else:
            response.update(t='Nope')
            player.progresbar += 1
        return {player.id_in_group: response}


page_sequence = [Introduction, Task]
